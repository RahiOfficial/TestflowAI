package com.testflow.examples;

import org.junit.jupiter.api.*;
import org.mockito.Mockito;
import static org.junit.jupiter.api.Assertions.*;

@DisplayName("🎴 Card Service Architecture Test Suite")
public class CardServiceTest {

    private Deck mockDeck;
    private GameService gameService;

    @BeforeEach
    void setUpConfiguration() {
        // Professional Lifecycle Initialization
        mockDeck = Mockito.mock(Deck.class);
        gameService = new GameService(mockDeck);
    }

    @Test
    @DisplayName("🚀 Should correctly draw a card when the deck contains active entities")
    void testDrawCardSuccessState() {
        Mockito.when(mockDeck.hasCards()).thenReturn(true);
        Mockito.when(mockDeck.pop()).thenReturn(new Card("Ace", "Spades"));

        Card drawnCard = gameService.drawNextCard();
        
        assertNotNull(drawnCard);
        assertEquals("Ace", drawnCard.getRank());
    }
}