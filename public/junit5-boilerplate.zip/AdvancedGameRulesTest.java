package com.testflow.examples;

import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

@DisplayName("🧠 Advanced Scoring Engine Tests")
public class AdvancedGameRulesTest {

    @Nested
    @DisplayName("🃏 When a player holds a BlackJack combination")
    class BlackJackRules {

        @Test
        @DisplayName("Score calculation should strictly evaluate to exactly 21")
        void testPerfectScoreEvaluation() {
            int score = GameRules.calculate(11, 10); // Ace + Ten
            assertEquals(21, score);
        }
    }
}